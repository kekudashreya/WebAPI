﻿using cinemakada.Data;
using cinemakada.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace cinemakada.Controllers
{
    //Need to add api controller. Because we dont have views
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : Controller
    {
        private readonly CinemakadaDbContext _cinemakadaDbContext;

        public UserController(CinemakadaDbContext cinemakadaDbContext)
        {
            _cinemakadaDbContext = cinemakadaDbContext;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllUser()
        {
            var user = await _cinemakadaDbContext.Users.ToListAsync();
            return Ok(user);   
        }

        [HttpPost]
        public async Task<IActionResult> AddUser([FromBody]User userRequest)
        {
            userRequest.Id= Guid.NewGuid();
            await _cinemakadaDbContext.Users.AddAsync(userRequest);
            await _cinemakadaDbContext.SaveChangesAsync();
            return Ok(userRequest);
        }
    }
}
