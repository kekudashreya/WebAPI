﻿using cinemakada.Data;
using cinemakada.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace cinemakada.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DemoController : Controller
    {
        private readonly CinemakadaDbContext _cinemakadaDbContext;
        public DemoController(CinemakadaDbContext cinemakadaDbContext)
        {

            _cinemakadaDbContext = cinemakadaDbContext;
        }


        [HttpGet]
        public async Task<IActionResult> GetAllDemo()
        {
            var demo = await _cinemakadaDbContext.Demos.ToListAsync();
            return Ok(demo);
        }

        [HttpPost]
        public async Task<IActionResult> Adddemo([FromBody] demo demoRequest)
        {
            //demoRequest.Id = Guid.NewGuid();
            await _cinemakadaDbContext.Demos.AddAsync(demoRequest);
            await _cinemakadaDbContext.SaveChangesAsync();
            return Ok(demoRequest);
        }

    }
}
