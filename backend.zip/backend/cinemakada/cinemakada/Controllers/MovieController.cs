﻿using cinemakada.Data;
using cinemakada.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Runtime.CompilerServices;

namespace cinemakada.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class MovieController : Controller
    {
        private readonly CinemakadaDbContext _cinemakadaDbContext;
        public MovieController(CinemakadaDbContext cinemakadaDbContext)
        {
            
            _cinemakadaDbContext = cinemakadaDbContext;
        }

        
        [HttpGet]
        public async Task<IActionResult> GetAllMovie()
        {
            var movie = await _cinemakadaDbContext.Movies.ToListAsync();
            return Ok(movie);
        }
       
        [HttpPost]
        public async Task<IActionResult> AddMovie([FromBody] Movies movieRequest)
        {
            movieRequest.Id= Guid.NewGuid();
            await _cinemakadaDbContext.Movies.AddAsync(movieRequest);
            await _cinemakadaDbContext.SaveChangesAsync();
            return Ok(movieRequest);
        }
        [HttpGet,Route("/api/edit-movies/edit-movie-detail/{id:Guid}")]
        public async Task<IActionResult> getMovie([FromRoute]Guid id)
        {
          var movie= await _cinemakadaDbContext.Movies.FirstOrDefaultAsync(x => x.Id == id);
            if(movie==null)
            {
                return BadRequest("Please edit again");
            }
            return Ok(movie);
        }

        [HttpPut, Route("/api/edit-movies/edit-movie-detail/{id:Guid}")]
        public async Task<IActionResult> UpdateMovie([FromRoute] Guid id,Movies updateMovieRequest)
        {
            var movie_id=await _cinemakadaDbContext.Movies.FindAsync(id);
            if(movie_id == null) { 
                return NotFound();
            }

            movie_id.MovieName = updateMovieRequest.MovieName;
            movie_id.MovieReview = updateMovieRequest.MovieReview;
            movie_id.MovieRating = updateMovieRequest.MovieRating;
            movie_id.MoviePoster = updateMovieRequest.MoviePoster;

            await _cinemakadaDbContext.SaveChangesAsync();

            return Ok( movie_id);
          

        }

        [HttpDelete,Route("/api/edit-movies/edit-movie-detail/{id:Guid}")]
        public async Task<IActionResult> DeleteMovie([FromRoute] Guid id)
        {
            var movie_id = await _cinemakadaDbContext.Movies.FindAsync(id);
            if(movie_id == null) {
                return NotFound();

            }
            _cinemakadaDbContext.Movies.Remove(movie_id);   
            await _cinemakadaDbContext.SaveChangesAsync();
            return Ok(movie_id);

        }



    }
}
