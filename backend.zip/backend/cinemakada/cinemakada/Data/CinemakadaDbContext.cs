﻿using cinemakada.Models;
using Microsoft.EntityFrameworkCore;
using System.Data.Common;

namespace cinemakada.Data
{
    public class CinemakadaDbContext : DbContext
    {
        public CinemakadaDbContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Movies> Movies { get; set; }
        
        public DbSet<demo> Demos { get; set; }
    }
}
