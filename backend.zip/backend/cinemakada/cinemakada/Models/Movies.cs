﻿namespace cinemakada.Models
{
    public class Movies
    {
        public Guid Id { get; set; }
        public string MovieName { get; set; }
        public string MovieReview { get; set; }
        public string MovieRating { get; set; }
        public string MoviePoster { get; set; }
    }
}
